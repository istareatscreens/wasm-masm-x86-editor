; Snake - https://github.com/meixinchoy/Snake-Game-Assembly-Language
; Copyright (c) 2020 meixinchoy, MIT License (see LICENSE in this folder).
; The lines marked "MASM editor" clear the console at start, fit the playfield to
; its size (the original draws for a fixed 120x30 console), show the controls, take
; the arrow keys as well as W A S D, and draw a coin that had to be placed again.

.386
.model flat, stdcall
.stack 4096
ExitProcess PROTO, dwExitCode: DWORD
INCLUDE Irvine32.inc

.data

xWall BYTE 52 DUP("#"),0

strScore BYTE "Your score is: ",0
score BYTE 0

strTryAgain BYTE "Try Again?  1=yes, 0=no",0
invalidInput BYTE "invalid input",0
strYouDied BYTE "you died ",0
strPoints BYTE " point(s)",0
blank BYTE "                                     ",0

snake BYTE "X", 104 DUP("x")

xPos BYTE 45,44,43,42,41, 100 DUP(?)
yPos BYTE 15,15,15,15,15, 100 DUP(?)

xPosWall BYTE 34,34,85,85			;position of upperLeft, lowerLeft, upperRight, lowerRignt wall 
yPosWall BYTE 5,24,5,24

xCoinPos BYTE ?
yCoinPos BYTE ?

inputChar BYTE "+"					; + denotes the start of the game
lastInputChar BYTE ?				

strSpeed BYTE "Speed (1-fast, 2-medium, 3-slow): ",0
strKeys BYTE "W A S D or arrows move, X quits    ",0	;(MASM editor) in the prompt's place
speed	DWORD 0

; (MASM editor) layout derived from the console size at start
csbi CONSOLE_SCREEN_BUFFER_INFO <>
cols BYTE 0
rows BYTE 0
ctrX BYTE 0
ctrY BYTE 0
scoreX BYTE 16
blank2 BYTE 14 DUP(" "),0

.code
main PROC
	call Clrscr			;(MASM editor) start on a clear screen: this program
						; addresses the console with absolute coordinates (Gotoxy)
	call InitLayout		;(MASM editor) fit the playfield to the console
	call DrawWall			;draw walls
	call DrawScoreboard		;draw scoreboard
	call ChooseSpeed		;let player to choose Speed
	mov dl, 1				;(MASM editor) the controls, where the speed prompt was
	mov dh, 2
	call Gotoxy
	mov edx, OFFSET strKeys
	call WriteString

	mov esi,0
	mov ecx,5
drawSnake:
	call DrawPlayer			;draw snake(start with 5 units)
	inc esi
loop drawSnake

	call Randomize
	call CreateRandomCoin
	call DrawCoin			;set up finish

	gameLoop::
		mov dl,cols						;move cursor to coordinates (top-right corner)
		dec dl
		mov dh,0
		call Gotoxy

		; get user key input
		call ReadKey
        jz noKey						;jump if no key is entered
		cmp al, "A"						;(MASM editor) W A S D with Caps Lock or Shift too
		jb notUpper
		cmp al, "Z"
		ja notUpper
		or al, 20h
		notUpper:
		cmp al, 0						;(MASM editor) an arrow key steers too:
		jne processInput				; ReadKey gives it as AL = 0, DX = its virtual key code
		mov al, "w"
		cmp dx, 26h						;VK_UP
		je processInput
		mov al, "s"
		cmp dx, 28h						;VK_DOWN
		je processInput
		mov al, "a"
		cmp dx, 25h						;VK_LEFT
		je processInput
		mov al, "d"
		cmp dx, 27h						;VK_RIGHT
		je processInput
		mov al, 0						;another special key, as before
		processInput:
		mov bl, inputChar
		mov lastInputChar, bl
		mov inputChar,al				;assign variables

		noKey:
		cmp inputChar,"x"	
		je exitgame						;exit game if user input x

		cmp inputChar,"w"
		je checkTop

		cmp inputChar,"s"
		je checkBottom

		cmp inputChar,"a"
		je checkLeft

		cmp inputChar,"d"
		je checkRight
		jne gameLoop					; reloop if no meaningful key was entered


		; check whether can continue moving
		checkBottom:	
		cmp lastInputChar, "w"
		je dontChgDirection		;cant go down immediately after going up
		mov cl, yPosWall[1]
		dec cl					;one unit ubove the y-coordinate of the lower bound
		cmp yPos[0],cl
		jl moveDown
		je died					;die if crash into the wall

		checkLeft:		
		cmp lastInputChar, "+"	;check whether its the start of the game
		je dontGoLeft
		cmp lastInputChar, "d"
		je dontChgDirection
		mov cl, xPosWall[0]
		inc cl
		cmp xPos[0],cl
		jg moveLeft
		je died					; check for left	

		checkRight:		
		cmp lastInputChar, "a"
		je dontChgDirection
		mov cl, xPosWall[2]
		dec cl
		cmp xPos[0],cl
		jl moveRight
		je died					; check for right	

		checkTop:		
		cmp lastInputChar, "s"
		je dontChgDirection
		mov cl, yPosWall[0]
		inc cl
		cmp yPos,cl
		jg moveUp
		je died				; check for up	
		
		moveUp:		
		mov eax, speed		;slow down the moving
		add eax, speed
		call delay
		mov esi, 0			;index 0(snake head)
		call UpdatePlayer	
		mov ah, yPos[esi]	
		mov al, xPos[esi]	;alah stores the pos of the snake's next unit 
		dec yPos[esi]		;move the head up
		call DrawPlayer		
		call DrawBody
		call CheckSnake

		
		moveDown:			;move down
		mov eax, speed
		add eax, speed
		call delay
		mov esi, 0
		call UpdatePlayer
		mov ah, yPos[esi]
		mov al, xPos[esi]
		inc yPos[esi]
		call DrawPlayer
		call DrawBody
		call CheckSnake


		moveLeft:			;move left
		mov eax, speed
		call delay
		mov esi, 0
		call UpdatePlayer
		mov ah, yPos[esi]
		mov al, xPos[esi]
		dec xPos[esi]
		call DrawPlayer
		call DrawBody
		call CheckSnake


		moveRight:			;move right
		mov eax, speed
		call delay
		mov esi, 0
		call UpdatePlayer
		mov ah, yPos[esi]
		mov al, xPos[esi]
		inc xPos[esi]
		call DrawPlayer
		call DrawBody
		call CheckSnake

	; getting points
		checkcoin::
		mov esi,0
		mov bl,xPos[0]
		cmp bl,xCoinPos
		jne gameloop			;reloop if snake is not intersecting with coin
		mov bl,yPos[0]
		cmp bl,yCoinPos
		jne gameloop			;reloop if snake is not intersecting with coin

		call EatingCoin			;call to update score, append snake and generate new coin	

jmp gameLoop					;reiterate the gameloop


	dontChgDirection:		;dont allow user to change direction
	mov inputChar, bl		;set current inputChar as previous
	jmp noKey				;jump back to continue moving the same direction 

	dontGoLeft:				;forbids the snake to go left at the begining of the game
	mov	inputChar, "+"		;set current inputChar as "+"
	jmp gameLoop			;restart the game loop

	died::
	call YouDied
	 
	playagn::			
	call ReinitializeGame			;reinitialise everything
	
	exitgame::
	exit
INVOKE ExitProcess,0
main ENDP


DrawWall PROC					;procedure to draw wall
	mov dl,xPosWall[0]
	mov dh,yPosWall[0]
	call Gotoxy	
	call DrawHWall				;draw upper wall (MASM editor: loop, any width)

	mov dl,xPosWall[1]
	mov dh,yPosWall[1]
	call Gotoxy	
	call DrawHWall				;draw lower wall

	mov dl, xPosWall[2]
	mov dh, yPosWall[2]
	mov eax,"#"	
	inc yPosWall[3]
	L11: 
	call Gotoxy	
	call WriteChar	
	inc dh
	cmp dh, yPosWall[3]			;draw right wall	
	jl L11

	mov dl, xPosWall[0]
	mov dh, yPosWall[0]
	mov eax,"#"	
	L12: 
	call Gotoxy	
	call WriteChar	
	inc dh
	cmp dh, yPosWall[3]			;draw left wall
	jl L12
	ret
DrawWall ENDP


DrawScoreboard PROC				;procedure to draw scoreboard
	mov dl,1
	mov dh,1
	call Gotoxy
	mov edx,OFFSET strScore		;print string that indicates score
	call WriteString
	mov eax,"0"
	call WriteChar				;scoreboard starts with 0
	ret
DrawScoreboard ENDP


ChooseSpeed PROC			;procedure for player to choose speed
	mov edx,0
	mov dl,1				
	mov dh,2
	call Gotoxy	
	mov edx,OFFSET strSpeed	; prompt to enter integers (1,2,3)
	call WriteString
	mov esi, 40				; milisecond difference per speed level
	mov eax,0
	call readInt			
	cmp ax,1				;input validation
	jl invalidspeed
	cmp ax, 3
	jg invalidspeed
	mul esi	
	mov speed, eax			;assign speed variable in mililiseconds
	ret

	invalidspeed:			;jump here if user entered an invalid number
	mov dl,1				
	mov dh,0
	call Gotoxy	
	mov edx, OFFSET invalidInput		;print error message		
	call WriteString
	mov ax, 1500
	call delay
	mov dl,1				
	mov dh,0
	call Gotoxy	
	mov edx, OFFSET blank2				;erase error message after 1.5 secs of delay
	call writeString
	call ChooseSpeed					;call procedure for user to choose again
	ret
ChooseSpeed ENDP

DrawPlayer PROC			; draw player at (xPos,yPos)
	mov dl,xPos[esi]
	mov dh,yPos[esi]
	call Gotoxy
	mov dl, al			;temporarily save al in dl
	mov al, snake[esi]		
	call WriteChar
	mov al, dl			
	ret
DrawPlayer ENDP

UpdatePlayer PROC		; erase player at (xPos,yPos)
	mov dl, xPos[esi]
	mov dh,yPos[esi]
	call Gotoxy
	mov dl, al			;temporarily save al in dl
	mov al, " "
	call WriteChar
	mov al, dl
	ret
UpdatePlayer ENDP

DrawCoin PROC						;procedure to draw coin
	mov eax,yellow (yellow * 16)
	call SetTextColor				;set color to yellow for coin
	mov dl,xCoinPos
	mov dh,yCoinPos
	call Gotoxy
	mov al,"X"
	call WriteChar
	mov eax,white (black * 16)		;reset color to black and white
	call SetTextColor
	ret
DrawCoin ENDP

CreateRandomCoin PROC				;procedure to create a random coin (MASM editor: inside the box)
	movzx eax, xPosWall[2]
	movzx ecx, xPosWall[0]
	sub eax, ecx
	dec eax					;box interior width
	call RandomRange
	add al, xPosWall[0]
	inc al
	mov xCoinPos,al
	movzx eax, yPosWall[1]
	movzx ecx, yPosWall[0]
	sub eax, ecx
	dec eax					;box interior height
	call RandomRange
	add al, yPosWall[0]
	inc al
	mov yCoinPos,al

	mov ecx, 5
	add cl, score				;loop number of snake unit
	mov esi, 0
checkCoinXPos:
	movzx eax,  xCoinPos
	cmp al, xPos[esi]		
	je checkCoinYPos			;jump if xPos of snake at esi = xPos of coin
	continueloop:
	inc esi
loop checkCoinXPos
	ret							; return when coin is not on snake
	checkCoinYPos:
	movzx eax, yCoinPos			
	cmp al, yPos[esi]
	jne continueloop			; jump back to continue loop if yPos of snake at esi != yPos of coin
	call CreateRandomCoin		; coin generated on snake, calling function again to create another set of coordinates
	ret							;(MASM editor) return the new position: the caller draws the coin
CreateRandomCoin ENDP

CheckSnake PROC				;check whether the snake head collides w its body 
	mov al, xPos[0] 
	mov ah, yPos[0] 
	mov esi,4				;start checking from index 4(5th unit)
	mov ecx,1
	add cl,score
checkXposition:
	cmp xPos[esi], al		;check if xpos same ornot
	je XposSame
	contloop:
	inc esi
loop checkXposition
	jmp checkcoin
	XposSame:				; if xpos same, check for ypos
	cmp yPos[esi], ah
	je died					;if collides, snake dies
	jmp contloop

CheckSnake ENDP

DrawBody PROC				;procedure to print body of the snake
		mov ecx, 4
		add cl, score		;number of iterations to print the snake body n tail	
		printbodyloop:	
		inc esi				;loop to print remaining units of snake
		call UpdatePlayer
		mov dl, xPos[esi]
		mov dh, yPos[esi]	;dldh temporarily stores the current pos of the unit 
		mov yPos[esi], ah
		mov xPos[esi], al	;assign new position to the unit
		mov al, dl
		mov ah,dh			;move the current position back into alah
		call DrawPlayer
		cmp esi, ecx
		jl printbodyloop
	ret
DrawBody ENDP

EatingCoin PROC
	; snake is eating coin
	inc score
	mov ebx,4
	add bl, score
	mov esi, ebx
	mov ah, yPos[esi-1]
	mov al, xPos[esi-1]	
	mov xPos[esi], al		;add one unit to the snake
	mov yPos[esi], ah		;pos of new tail = pos of old tail

	cmp xPos[esi-2], al		;check if the old tail and the unit before is on the yAxis
	jne checky				;jump if not on the yAxis

	cmp yPos[esi-2], ah		;check if the new tail should be above or below of the old tail 
	jl incy			
	jg decy
	incy:					;inc if below
	inc yPos[esi]
	jmp continue
	decy:					;dec if above
	dec yPos[esi]
	jmp continue

	checky:					;old tail and the unit before is on the xAxis
	cmp yPos[esi-2], ah		;check if the new tail should be right or left of the old tail
	jl incx
	jg decx
	incx:					;inc if right
	inc xPos[esi]			
	jmp continue
	decx:					;dec if left
	dec xPos[esi]

	continue:				;add snake tail and update new coin
	call DrawPlayer		
	call CreateRandomCoin
	call DrawCoin			

	mov dl,scoreX			; write updated score
	mov dh,1
	call Gotoxy
	mov al,score
	call WriteInt
	ret
EatingCoin ENDP


YouDied PROC
	mov eax, 1000
	call delay
	Call ClrScr	
	
	mov dl,	ctrX
	sub dl, 4
	mov dh, ctrY
	sub dh, 3
	call Gotoxy
	mov edx, OFFSET strYouDied	;"you died"
	call WriteString

	mov dl,	ctrX
	sub dl, 5
	mov dh, ctrY
	dec dh
	call Gotoxy
	movzx eax, score
	call WriteInt
	mov edx, OFFSET strPoints	;display score
	call WriteString

	mov dl,	ctrX
	sub dl, 11
	mov dh, ctrY
	add dh, 2
	call Gotoxy
	mov edx, OFFSET strTryAgain
	call WriteString		;"try again?"

	retry:
	mov dh, ctrY
	add dh, 3
	mov dl,	ctrX
	sub dl, 5
	call Gotoxy
	call ReadInt			;get user input
	cmp al, 1
	je playagn				;playagn
	cmp al, 0
	je exitgame				;exitgame

	mov dh,	ctrY
	inc dh
	mov dl, ctrX
	sub dl, 5
	call Gotoxy
	mov edx, OFFSET invalidInput	;"Invalid input"
	call WriteString		
	mov dl,	ctrX
	sub dl, 5
	mov dh, ctrY
	add dh, 3
	call Gotoxy
	mov edx, OFFSET blank2			;erase previous input
	call WriteString
	jmp retry						;let user input again
YouDied ENDP

ReinitializeGame PROC		;procedure to reinitialize everything
	call PlaceSnake			;(MASM editor) snake back to the box centre
	mov score,0				;reinitialize score
	mov lastInputChar, 0
	mov	inputChar, "+"			;reinitialize inputChar and lastInputChar
	dec yPosWall[3]			;reset wall position
	Call ClrScr
	jmp main				;start over the game
ReinitializeGame ENDP
; ---- MASM editor: console-size-adaptive layout --------------------
InitLayout PROC
	INVOKE GetStdHandle, STD_OUTPUT_HANDLE
	INVOKE GetConsoleScreenBufferInfo, eax, ADDR csbi
	movzx eax, csbi.dwSize.X			;columns = buffer width, at most 129: the game compares
						; x positions with signed jumps (jl, jg), so they must stay below 128
	cmp eax, 129
	jbe c1
	mov eax, 129
c1:	mov cols, al
	movzx eax, csbi.srWindow.Bottom	;rows = visible window height (capped)
	movzx ecx, csbi.srWindow.Top
	sub eax, ecx
	inc eax
	cmp eax, 100
	jbe r1
	mov eax, 100
r1:	mov rows, al
	; box: columns 1..cols-2, rows 3..rows-2 (row 1 score, row 2 speed prompt)
	mov xPosWall[0], 1
	mov xPosWall[1], 1
	mov al, cols
	sub al, 2
	mov xPosWall[2], al
	mov xPosWall[3], al
	mov yPosWall[0], 3
	mov yPosWall[2], 3
	mov al, rows
	sub al, 2
	mov yPosWall[1], al
	mov yPosWall[3], al
	movzx eax, xPosWall[0]			;centre of the box
	movzx ecx, xPosWall[2]
	add eax, ecx
	shr eax, 1
	mov ctrX, al
	movzx eax, yPosWall[0]
	movzx ecx, yPosWall[1]
	add eax, ecx
	shr eax, 1
	mov ctrY, al
	call PlaceSnake
	ret
InitLayout ENDP

PlaceSnake PROC				;5 units on the centre row, head to the right
	mov al, ctrX
	add al, 2
	mov xPos[0], al
	dec al
	mov xPos[1], al
	dec al
	mov xPos[2], al
	dec al
	mov xPos[3], al
	dec al
	mov xPos[4], al
	mov al, ctrY
	mov yPos[0], al
	mov yPos[1], al
	mov yPos[2], al
	mov yPos[3], al
	mov yPos[4], al
	ret
PlaceSnake ENDP

DrawHWall PROC				;'#' from xPosWall[0] to xPosWall[2] on the current row (dh)
	mov dl, xPosWall[0]
h1:	call Gotoxy
	mov al, "#"
	call WriteChar
	inc dl
	cmp dl, xPosWall[2]
	jbe h1
	ret
DrawHWall ENDP

END main