@mkdir bin 2>nul
%~dp0JWASM\JWASM.EXE /Zd /coff /Zne /Zg /I %~dp0irvine /Fo"bin\%~1.obj" "%~1.asm"
@echo Off
if %ERRORLEVEL% GEQ 1 goto :eof
@echo on
%~dp0JWLINK\JWlink.exe format windows pe LIBPATH %~dp0irvine\ LIBRARY %~dp0irvine\Irvine32.lib LIBRARY %~dp0irvine\Kernel32.lib LIBRARY %~dp0irvine\User32.lib file 'bin\%~1.obj' name 'bin\%~1.exe' 
@echo Off
%~dp0FL.exe "bin\%~1.exe"
@echo on
"bin\%~1.exe"
