%~dp0JWASM\JWASM.EXE /Zd /coff /I %~dp0irvine "%~1.asm"
@echo Off
if %ERRORLEVEL% GEQ 1 goto execute
@echo on
%~dp0JWLINK\JWlink.exe format windows pe LIBPATH %~dp0irvine\ LIBRARY %~dp0irvine\Irvine32.lib LIBRARY %~dp0irvine\Kernel32.lib LIBRARY %~dp0irvine\User32.lib file '%~1.obj' 
@echo Off
%~dp0FL.exe "%~1.exe"
@echo on
"%~1.exe"
