@setlocal
@set bw_mode=
@set bw_zi=
@set bw_cv=
@goto switch
:switch
@if /i "%~1"=="/debug" set bw_zi= /Zi
@if /i "%~1"=="/debug" set bw_cv= DEBUG CODEVIEW ALL
@if /i "%~1"=="/debug" goto switched
@if /i "%~1"=="/c" set bw_mode=c
@if /i "%~1"=="/c" goto switched
@if /i "%~1"=="/dll" set bw_mode=dll
@if /i "%~1"=="/dll" goto switched
@goto program
:switched
@shift
@goto switch
:program
@if "%~1"=="" goto usage
@if /i "%~x1"==".obj" goto usage
@set bw_out=
@set bw_asm=
@set bw_obj=
@goto next
:next
@if "%~1"=="" goto assemble
@if /i "%~x1"==".obj" set bw_obj=%bw_obj% file "%~1"
@if /i "%~x1"==".obj" goto shifted
@set "bw_bin=bin"
@set "bw_dir="
@if not "%~nx1"=="%~1" set "bw_bin=%~dp1bin"
@if not "%~nx1"=="%~1" set "bw_dir=%~dp1"
@set "bw_name=%~nx1"
@set "bw_src=%~1.asm"
@if /i "%~x1"==".asm" set "bw_name=%~n1"
@if /i "%~x1"==".asm" set "bw_src=%~1"
@mkdir "%bw_bin%" 2>nul
@set bw_asm=%bw_asm% /Fo"%bw_bin%\%bw_name%.obj" /Fw"%bw_bin%\%bw_name%.err" "%bw_src%"
@set bw_obj=%bw_obj% file "%bw_bin%\%bw_name%.obj"
@if not defined bw_out set "bw_def=%bw_dir%%bw_name%.def"
@if not defined bw_out set "bw_out=%bw_bin%\%bw_name%"
@goto shifted
:shifted
@shift
@goto next
:assemble
%~dp0JWASM\JWASM.EXE%bw_zi% /coff /Zne /Zg /I %~dp0irvine%bw_asm%
@if %ERRORLEVEL% GEQ 1 goto :eof
@if "%bw_mode%"=="c" goto :eof
@set bw_fmt=
@set bw_opt=
@if "%bw_mode%"=="dll" set bw_fmt= dll
@if "%bw_mode%"=="dll" set bw_opt= OPTION IMPLIB="%bw_out%.lib"
@if exist "%bw_def%" set bw_opt= OPTION DEF="%bw_def%" OPTION IMPLIB="%bw_out%.lib"
@del "%bw_out%.exe" "%bw_out%.dll" >nul 2>&1
%~dp0JWLINK\JWlink.exe format windows pe%bw_fmt%%bw_cv% LIBPATH %~dp0irvine;%~dp0lib LIBRARY %~dp0irvine\Irvine32.lib LIBRARY %~dp0irvine\Kernel32.lib LIBRARY %~dp0irvine\User32.lib%bw_obj% OPTION MAP="%bw_out%.map"%bw_opt%
@if %ERRORLEVEL% GEQ 1 goto :eof
@if not exist "%bw_out%.exe" goto :eof
@%~dp0FL.exe "%bw_out%.exe"
"%bw_out%.exe"
@goto :eof
:usage
@echo Usage: assemble [/debug] [/c ^| /dll] program [file ...]
