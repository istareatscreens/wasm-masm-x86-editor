Import libraries for Windows DLLs, for INCLUDELIB: the linker finds them in this folder (its LIBPATH is
C:\files\irvine;C:\files\lib). Kernel32.lib and User32.lib are Irvine's, in C:\files\irvine.

Each names the exports of one DLL of Wine 6.0, which runs the programs here, and holds no code. A program
imports each function by its name, as with Microsoft's own import libraries, so it also runs on Windows.
They were made by Microsoft LIB (/MACHINE:X86 /DEF:) from Wine 6.0's module-definition files: lib<dll>.def as
Wine installs it (winebuild, from dlls/<dll>/<dll>.spec), and for msvcrt.lib one made from
dlls/msvcrt/msvcrt.spec by winebuild's rules. Wine is free software under the GNU LGPL 2.1 or later:
https://www.winehq.org, source at https://dl.winehq.org/wine/source/6.0/.
